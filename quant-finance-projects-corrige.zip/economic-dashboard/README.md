# Economic Dashboard

Interactive Streamlit dashboard comparing **GDP, inflation and unemployment** across
countries (France, Germany, United Kingdom, United States, Spain, Italy, Morocco,
United Arab Emirates, Saudi Arabia), with World Bank data.

## Features

- Multi-country selection and period slider
- Table of the latest available values
- GDP, inflation and unemployment charts
- CSV export of the selected data

## Run

```bash
python fetch_data.py               # downloads the data from the World Bank API into data/
streamlit run economic_dashboard.py
```

Edit `COUNTRIES` in `fetch_data.py` to change the list of countries.
