"""
Download macroeconomic indicators from the World Bank API and save them as CSV files
in the data/ folder, in the format expected by economic_dashboard.py.

Usage:  python fetch_data.py

Author: Hamza Mennani
"""

from pathlib import Path

import pandas as pd
import requests

COUNTRIES = ["FRA", "DEU", "GBR", "USA", "ESP", "ITA", "MAR", "ARE", "SAU"]
START_YEAR, END_YEAR = 2000, 2025

INDICATORS = {
    "gdp_data.csv": ("NY.GDP.MKTP.CD", "GDP"),                 # GDP, current USD
    "inflation_data.csv": ("FP.CPI.TOTL.ZG", "Inflation"),     # CPI inflation, annual %
    "unemployment_data.csv": ("SL.UEM.TOTL.ZS", "Unemployment"),  # unemployment, % of labour force
}

DATA_DIR = Path(__file__).parent / "data"


def fetch_indicator(indicator: str, value_name: str) -> pd.DataFrame:
    url = (f"https://api.worldbank.org/v2/country/{';'.join(COUNTRIES)}/indicator/{indicator}"
           f"?format=json&per_page=20000&date={START_YEAR}:{END_YEAR}")
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    payload = response.json()
    if len(payload) < 2 or payload[1] is None:
        raise RuntimeError(f"No data returned for {indicator}")
    rows = [
        {"Year": int(item["date"]), "Country": item["country"]["value"], value_name: item["value"]}
        for item in payload[1]
        if item["value"] is not None
    ]
    return pd.DataFrame(rows).sort_values(["Country", "Year"])


def main():
    DATA_DIR.mkdir(exist_ok=True)
    for filename, (indicator, value_name) in INDICATORS.items():
        df = fetch_indicator(indicator, value_name)
        df.to_csv(DATA_DIR / filename, index=False)
        print(f"Saved {filename}: {len(df)} rows")


if __name__ == "__main__":
    main()
