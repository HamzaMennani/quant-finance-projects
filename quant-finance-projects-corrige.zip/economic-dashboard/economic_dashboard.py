"""
Economic indicator dashboard (Streamlit).

Run:  python fetch_data.py        # downloads the data once (World Bank API)
      streamlit run economic_dashboard.py

Author: Hamza Mennani
"""

from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

DATA_DIR = Path(__file__).parent / "data"
FILES = {
    "GDP": "gdp_data.csv",
    "Inflation": "inflation_data.csv",
    "Unemployment": "unemployment_data.csv",
}

st.set_page_config(page_title="Economic Dashboard", layout="wide")
st.title("Economic Indicator Dashboard")
st.write("GDP, inflation and unemployment by country (source: World Bank).")


@st.cache_data
def load_data() -> pd.DataFrame:
    """Merge the three indicator files into one table: Year, Country, GDP, Inflation, Unemployment."""
    frames = []
    for name, filename in FILES.items():
        path = DATA_DIR / filename
        if not path.exists():
            raise FileNotFoundError(path)
        frames.append(pd.read_csv(path).set_index(["Year", "Country"])[[name]])
    return pd.concat(frames, axis=1).reset_index()


try:
    data = load_data()
except FileNotFoundError as missing:
    st.error(f"Missing data file: {missing.args[0]}. Run `python fetch_data.py` first.")
    st.stop()

data["GDP (USD bn)"] = data["GDP"] / 1e9

# --- Selection -------------------------------------------------------------
countries = sorted(data["Country"].unique())
default = [c for c in ["France", "Morocco"] if c in countries] or countries[:1]
selected = st.multiselect("Countries", countries, default=default)
year_min, year_max = int(data["Year"].min()), int(data["Year"].max())
years = st.slider("Period", year_min, year_max, (max(year_min, year_max - 15), year_max))

view = data[data["Country"].isin(selected) & data["Year"].between(*years)].sort_values("Year")
if view.empty:
    st.info("Select at least one country.")
    st.stop()

# --- Latest values ---------------------------------------------------------
st.subheader("Latest available values")
latest = (view.dropna(subset=["Inflation"]).sort_values("Year").groupby("Country").tail(1)
          [["Country", "Year", "GDP (USD bn)", "Inflation", "Unemployment"]]
          .round(1).set_index("Country"))
st.dataframe(latest, width="stretch")

# --- Charts ----------------------------------------------------------------
col1, col2 = st.columns(2)
with col1:
    st.plotly_chart(px.line(view, x="Year", y="GDP (USD bn)", color="Country",
                            title="GDP (current USD bn)"), width="stretch")
with col2:
    st.plotly_chart(px.line(view, x="Year", y="Inflation", color="Country",
                            title="Inflation (annual %)"), width="stretch")
st.plotly_chart(px.line(view, x="Year", y="Unemployment", color="Country",
                        title="Unemployment (% of labour force)"), width="stretch")

# --- Download --------------------------------------------------------------
st.download_button("Download selected data (CSV)", view.to_csv(index=False),
                   "economic_indicators.csv", "text/csv")
